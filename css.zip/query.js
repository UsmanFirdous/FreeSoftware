var express = require('express');
const multer = require('multer');
var app = express();
const layout = require('express-layout')

const validator = require('express-validator')

const bodyParser = require('body-parser')
app.use(bodyParser.json());
const urlencoded=app.use(bodyParser.urlencoded({ extended: false }));
const formidable = require('formidable');

const uniqueString = require('unique-string');

const fileUpload = require('express-fileupload');

const session = require('express-session');

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "usaf.com.pk",
  user: "usafcomp_malik_shaf",
  password: "moonchand786!@#$",
  database: "usafcomp_usaf"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Sql Connected! on query");
});


function makeid(length) {
  var result           = '';
  var characters       = '0123456789';
  var charactersLength = characters.length;
  for ( var i = 0; i < length; i++ ) {
     result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}






app.use(session({secret: 'ssshhhhh',saveUninitialized: false,resave: true}));


var storage =   multer.diskStorage({
	destination: function (req, file, callback) {
		var dir='./public/Files/';
		callback(null, dir);
	},
	filename: function (req, file, callback) {
		
		if (file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg'|| file.mimetype == 'image/png')
		{
		picname= makeid(9)+makeid(9)+file.originalname.toLowerCase().split(' ').join('-');
		callback(null , picname );
		}
		else
		{
			filename= makeid(9)+makeid(9) +file.originalname.toLowerCase().split(' ').join('-');
			callback(null , filename );
			}
	}
});	
var uploadimg = multer({ storage : storage}).single('img');



app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended:true
}));
var path = require('path');
var util = require('util');
var os = require('os');



app.use(bodyParser.urlencoded({extended : true}));


app.get('/admin_malik/ad_papular_soft', (req, res) => {
	if(req.session.name)
	{
		res.render('admin_malik/ad_papular_soft',{
			data: {},
		errors: {}
		});
	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
	
});

app.get('/admin_malik/admin_papular', (req, res) => {
	if(req.session.name)
	{
		con.query("SELECT * FROM papular ORDER BY Date DESC", function (err, result) {
			if (err) throw err;
			res.render('admin_malik/admin_papular',{
				Papular: result
				});
		
		});

	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});
app.get('/admin_malik/admin_windows', (req, res) => {
	if(req.session.name)
	{
		con.query("SELECT * FROM windows ORDER BY Date DESC", function (err, result) {
			if (err) throw err;
			res.render('admin_malik/admin_windows',{
				Papular: result
				});
		
		});

	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});
app.get('/admin_malik/admin_linux', (req, res) => {
	if(req.session.name)
	{
		con.query("SELECT * FROM linux ORDER BY Date DESC", function (err, result) {
			if (err) throw err;
			res.render('admin_malik/admin_linux',{
				Papular: result
				});
		
		});

	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});
app.get('/admin_malik/admin_mac', (req, res) => {
	if(req.session.name)
	{
		con.query("SELECT * FROM mac ORDER BY Date DESC", function (err, result) {
			if (err) throw err;
			res.render('admin_malik/admin_mac',{
				Papular: result
				});
		
		});

	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});
app.get('/admin_malik/admin_android', (req, res) => {
	if(req.session.name)
	{
		con.query("SELECT * FROM android ORDER BY Date DESC", function (err, result) {
			if (err) throw err;
			res.render('admin_malik/admin_android',{
				Papular: result
				});
		
		});

	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});

app.post('/delete_record',function(req,res,next){
	if(req.session.name)
	{
		if(req.body.type=="Papular")
		{
			con.query("DELETE FROM papular WHERE id=?",[
				req.body.id
			], function (err, result) {
				if (err) throw err;
				res.redirect('/admin_malik/admin_papular');
			
			});

		}
		else if(req.body.type=="Windows")
		{
			con.query("DELETE FROM windows WHERE id=?",[
				req.body.id
			], function (err, result) {
				if (err) throw err;
				res.redirect('/admin_malik/admin_windows');
			
			});

		}
		else if(req.body.type=="Linux")
		{
			con.query("DELETE FROM linux WHERE id=?",[
				req.body.id
			], function (err, result) {
				if (err) throw err;
				res.redirect('/admin_malik/admin_linux');
			
			});
			
		}
		else if(req.body.type=="Mac")
		{
			con.query("DELETE FROM mac WHERE id=?",[
				req.body.id
			], function (err, result) {
				if (err) throw err;
				res.redirect('/admin_malik/admin_mac');
			
			});
			
		}
		else if(req.body.type=="APK")
		{
			con.query("DELETE FROM android WHERE id=?",[
				req.body.id
			], function (err, result) {
				if (err) throw err;
				res.redirect('/admin_malik/admin_android');
			
			});
			
		}
	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});
app.post('/admin_malik/admin_update',function(req,res,next){
	if(req.session.name)
	{
		if(req.body.type=="Papular")
		{
			con.query("SELECT * FROM papular WHERE id=?",[
				req.body.id
			 ], function (err, found) {
			 res.render('admin_malik/admin_update',{
				Found:found,
				Type:"Papular",
				Data:''
			 })
			
			})
		}
		else if(req.body.type=="Windows")
		{
			con.query("SELECT * FROM windows WHERE id=?",[
				req.body.id
			 ], function (err, found) {
			 res.render('admin_malik/admin_update',{
				Found:found,
				Type:"Windows",
				Data:''
			 })
			
			})

		}
		else if(req.body.type=="Linux")
		{
			con.query("SELECT * FROM linux WHERE id=?",[
				req.body.id
			 ], function (err, found) {
			 res.render('admin_malik/admin_update',{
				Found:found,
				Type:"Linux",
				Data:''
			 })
			
			})
			
		}
		else if(req.body.type=="Mac")
		{
			con.query("SELECT * FROM mac WHERE id=?",[
				req.body.id
			 ], function (err, found) {
			 res.render('admin_malik/admin_update',{
				Found:found,
				Type:"Mac",
				Data:''
			 })
			
			})
			
		}
		else if(req.body.type=="APK")
		{
			con.query("SELECT * FROM android WHERE id=?",[
				req.body.id
			 ], function (err, found) {
			 res.render('admin_malik/admin_update',{
				Found:found,
				Type:"APK",
				Data:''
			 })
			
			})
			
		}
	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});

app.post('/icon_update', (req, res) => {
	if(req.session.name)
	{
	uploadimg(req,res,function(err) {
		let errors=[];
		if(err) {
			console.log("error");
					return res.end("first error Error uploading.");
			}
		if(req.body.type=="Windows")
		{
			con.query("UPDATE windows SET Icon=? WHERE id =?",[
				'Files/'+ picname,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM windows WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Windows",
						Data:"In Windows Category Image Record Successfully Updated"
					});
				
				});
				
			});


		}
		else if(req.body.type=="Linux")
		{
			con.query("UPDATE linux SET Icon=? WHERE id =?",[
				'Files/'+ picname,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM linux WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Linux",
						Data:"In Linux Category Image Record Successfully Updated"
					});
				
				});
				
			});


		}
		else if(req.body.type=="Mac")
		{
			con.query("UPDATE mac SET Icon=? WHERE id =?",[
				'Files/'+ picname,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM mac WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Mac",
						Data:"In Mac Category Image Record Successfully Updated"
					});
				
				});
				
			});

			
		}
		else if(req.body.type=="APK")
		{
			con.query("UPDATE android SET Icon=? WHERE id =?",[
				'Files/'+ picname,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM android WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"APK",
						Data:"In Android Category Image Record Successfully Updated"
					});
				
				});
				
			});

	
		}
		else if(req.body.type=="Papular")
		{
			con.query("UPDATE papular SET Icon=? WHERE id =?",[
				'Files/'+ picname,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM papular WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Papular",
						Data:"In Papular Category Image Record Successfully Updated"
					});
				
				});
				
			});

	
		}
		
		
		
		
		});


	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
});

app.post('/admin_record_update', (req, res) => {
	if(req.session.name)
	{

		if(req.body.type=="Papular")
		{
			con.query("UPDATE papular SET Title =?,Size=?,Version=? WHERE id =?",[
				req.body.title,
				req.body.size,
				req.body.version,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM papular WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Papular",
						Data:"In Papular Category Fields Record Successfully Updated"
					});
				
				});
				
			});

		}
		else if(req.body.type=="Windows")
		{
			con.query("UPDATE windows SET Title =?,Size=?,Version=?,Path=? WHERE id =?",[
				req.body.title,
				req.body.size,
				req.body.version,
				 req.body.link,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM windows WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Windows",
						Data:"In Windows Category Fields Record Successfully Updated"
					});
				
				});
				
			});

		}
		else if(req.body.type=="Linux")
		{
			con.query("UPDATE linux SET Title =?,Size=?,Version=?,Path=? WHERE id =?",[
				req.body.title,
				req.body.size,
				req.body.version,
				 req.body.link,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM linux WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Linux",
						Data:"In Linux Category Fields Record Successfully Updated"
					});
				
				});
				
			});
	

		}
		else if(req.body.type=="Mac")
		{
			con.query("UPDATE mac SET Title =?,Size=?,Version=?,Path=? WHERE id =?",[
				req.body.title,
				req.body.size,
				req.body.version,
				 req.body.link,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM mac WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"Mac",
						Data:"In Mac Category Fields Record Successfully Updated"
					});
				
				});
				
			});
		}
		else if(req.body.type=="APK")
		{
			con.query("UPDATE android SET Title =?,Size=?,Version=?,Path=? WHERE id =?",[
				req.body.title,
				req.body.size,
				req.body.version,
				 req.body.link,
				 req.body.id
			 ], function (err, f) {
				if (err) throw err;
				con.query("SELECT * FROM android WHERE id=?",[
					req.body.id
				],function (err, found) {
					if (err) throw err;
					res.render('admin_malik/admin_update',{
						Found:found,
						Type:"APK",
						Data:"In Android Category Fields Record Successfully Updated"
					});
				
				});
				
			});
		}
		
		
		
		
		
	}
	else
	{
		res.end("You have not permission to Access this page!");
	}


});

app.post('/admin_malik/admin_search', (req, res) => {
	if(req.session.name)
	{
	var query=req.body.title.split('');
	
	var check=0;
		for (var i=0;i<query.length;i++)
		{
			if(!((query[i]>='a' && query[i]<='z') || (query[i]>='A' && query[i]<='Z') || (query[i]>='0' && query[i]<='9') || (query[i]==' ')) )
			{
           check=1;
			}
		}
		if(check==1)
		{
			//console.log("ahhahaaaaaaaaaaaaaaa")
			res.render('admin_malik/admin_search',{
				Found:'',
				Type:req.body.type,
				Key:req.body.title
					});
		}

	if(req.body.type=="Windows")
	{			
		
				con.query("SELECT * FROM windows where Title LIKE ?",[
					'%'+req.body.title+'%'
					
				],function (err, found) {
					 console.log(found);
					res.render('admin_malik/admin_search',{
						Found:found,
						Type:req.body.type,
						Key:req.body.title
							});
						});
        

	}
	else if(req.body.type=="Linux")
	{
		con.query("SELECT * FROM linux where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('admin_malik/admin_search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});

	}
	else if(req.body.type=="Mac")
	{
		con.query("SELECT * FROM mac where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('admin_malik/admin_search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});
	}
	else if(req.body.type=="APK")
	{
		con.query("SELECT * FROM android where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('admin_malik/admin_search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});

	}
}
else
{
	res.end("You have not permission to Access this page!");
}
});










var middleware = [
  layout(),
	express.static(path.join(__dirname, 'public')),
];
app.use(middleware);
const routes = require('./routes');



app.use('/', routes);

	app.listen(3001, function () {
		console.log('server started on port 3001');
	});


		  
