const express = require('express')
var nodemailer = require('nodemailer');
var fs = require('fs');
const router = express.Router()
var app = express();
var check=0;
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "usaf.com.pk",
  user: "usafcomp_malik_shaf",
  password: "moonchand786!@#$",
  database: "usafcomp_usaf"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Sql Connected! on router");
});
function makeid(length) {
  var result           = '';
  var characters       = '0123456789';
  var charactersLength = characters.length;
  for ( var i = 0; i < length; i++ ) {
     result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}

var gname="";
var myData=0;
var myData2=0;
const bodyParser = require('body-parser')
const formidable = require('formidable');
const multer = require('multer');
const uniqueString = require('unique-string');
var path = require('path');



var picname="";
var filename="";

var storage =   multer.diskStorage({
	destination: function (req, file, callback) {
		var dir='./public/Files/';
		callback(null, dir);
	},
	filename: function (req, file, callback) {
		
		if (file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg'|| file.mimetype == 'image/png')
		{
		picname= makeid(9)+makeid(9)+file.originalname.toLowerCase().split(' ').join('-');
		callback(null , picname );
		}
		else
		{
			filename= makeid(9)+makeid(9) +file.originalname.toLowerCase().split(' ').join('-');
			callback(null , filename );
			}
	}
});	
var uploadpic = multer({ storage : storage}).array('uploadImage',2);
/////////////////////////////////////////////////////////////
 




/*var storaged =   multer.diskStorage({
	
	destination: function (req, file, callback) {
		var dir='./public/Files/' + req.body.title;
		callback(null, dir);
	},
	filename: function (req, file, callback) {
		filename='USAF.Com.PK_'+req.body.title + '.' + makeid(9) + '.zip';
	  // picname= gname + '.jpg';
		callback(null , filename );
	}
});	
var uploadfile = multer({ storage : storaged}).single('uploadfile');

*/
app.get('/',function(req,res){
      res.sendFile(__dirname + "/index.html");
});


app.set('view engine', 'ejs');




var sess;

router.get('/', (req, res) => {
	con.query("SELECT * FROM papular ORDER BY Date DESC", function (err, result) {
		if (err) throw err;
		res.render('index',{
			Papular: result
			});
	});
	
});
router.post('/download', (req, res) => {
	
	
 con.query("SELECT * FROM windows WHERE Title=? LIMIT 1",[
  req.body.title
 ], function (err, windows) {
	if (err) throw err;
	con.query("SELECT * FROM linux WHERE Title=? LIMIT 1",[
		req.body.title
	 ], function (err, linux) {
		con.query("SELECT * FROM mac WHERE Title=? LIMIT 1",[
			req.body.title
		 ], function (err, mac) {
		
			con.query("SELECT * FROM android WHERE Title=? LIMIT 1",[
				req.body.title
			 ], function (err, android) {
				
		
				res.render('download',{
					Windows:windows,
					Apk:android,
					Linux:linux,
					Mac:mac,
			
		});
	});
		
});
		
	});

});




});



router.get('/admin_malik/malik_shaf_login', (req, res) => {
	
	if(req.session.name)
	{
		res.redirect('/admin_malik/ad_papular_soft');
	}
	else
	{
	res.render('admin_malik/malik_shaf_login',{
		data: {},
	errors: {}
	});
}

});

router.post('/login_confirm',function(req,res){

	let errors=[];

	if(!req.body.email){
		errors.push("Please Enter your Email Address");
	}
	if(!req.body.pass){
		errors.push("Please Enter your password");
	}
	if(errors.length>0)
		{
			 res.render('malik_shaf_login',{
				 errors:errors,
				 
			 });
		}
		
		con.query("SELECT * FROM admin", function (err, result) {
			if (err) throw err;
			let er=[];
			if(req.body.email==result[0].Email && req.body.pass==result[0].Password)
			{
				req.session.name=result[0].Name;
				res.redirect('admin_malik/ad_papular_soft');
			
			}
			else
			{
				
				er.push("InValid Email Address/Password");
				res.render('admin_malik/malik_shaf_login',{
					errors:er,
				});

			}
			

		
		});

	});

	router.get('/admin_malik/logout',(req,res) => {
		if(req.session.name)
		{
			req.session.destroy((err) => {
				if(err) {
						return console.log(err);
				}
				res.redirect('malik_shaf_login');
		});
		}
	});





router.get('/contact', (req, res) => {
	
	res.render('contact',{
		data: {},
	errors: {}
	});

});
router.post('/success', (req, res) => {
	
	var transporter = nodemailer.createTransport({
		host: 'usaf.com.pk',
    port: 465,
    secure: true,
		auth: {
			user: 'info@usaf.com.pk',
			pass: 'moonchand786!@#$'
		},
		tls: {
			rejectUnauthorized: false
		}
	});

	var mailOptions = {
		from: 'info@usaf.com.pk',
		to: 'sagarvivian@gmail.com, zirwamaninaina@gmail.com',
		subject: 'Query/Message/Support',
		html:'<h1>Welcome to Usaf Support!</h1><h2>Name: <span style="color:#fb6340">'+req.body.name+'</span></h2><h2>Email: <span style="color:#fb6340">'+req.body.email+'</span></h2><h2>Address: <span style="color:#fb6340">'+req.body.address+'</span></h2><h2>Query: <span style="color:#fb6340">'+req.body.query+'</span></h2>'

	};
	
	transporter.sendMail(mailOptions, function(error, info){
		if (error) {
			console.log(error);
		} else {
			console.log('Email sent: ' + info.response);
		}
	});

	res.render('success',{
		data: 'Thanku So Much For Contact Us,Your Query successfully Received we will contact with you as soon as possible.',
	errors: {}
	});

});
router.get('/overview', (req, res) => {
	
	res.render('overview',{
		data: {},
	errors: {}
	});

});
router.get('/custom', (req, res) => {
	
	res.render('custom',{
		data: {},
	errors: {}
	});

});
router.get('/register_admin', (req, res) => {
	
	res.render('register_admin',{
		data: {},
	errors: {}
	});

});
router.post('/register_admin_confirm', (req, res) => {
	let errors=[];
	if(!req.body.name)
	{
      errors.push("Please Enter Your Name!");
	}
	else if(!req.body.email)
	{
		errors.push("Please Enter Your Name!");
	}
	else if(!req.body.pass)
	{
		errors.push("Please Enter Your Name!");
	}
	if(errors.length>0)
	{
		console.log(errors);
		res.render('register_admin',{
		errors: errors
		});
		
	} 

	var a=new Admin();
	a.Name=req.body.name;
	a.Email=req.body.email;
	a.Password=req.body.pass;

	var e=[];
	a.save(function(err) {
		if (err>0)
		{
			e.push(err);
			
			return res.end(err);
		
		}
		else
		{
		//	e.push("Record Succesfully Saved in MongoDb");
			return res.end("Admin Successfully Addedd into Mongodb");
		}
				
});

   
	  
	

});
router.get('/windows', (req, res) => {
	
	con.query("SELECT * FROM windows ORDER BY Date DESC", function (err, result) {
		if (err) throw err;
		res.render('windows',{
			Windows: result
			});
	});
});
router.get('/download_windows/:id', (req, res) => {
	
	
	con.query("SELECT * FROM windows WHERE uid=? LIMIT 1",[
		req.params.id
	 ], function (err, found) {
		//console.log(windows[0].Path);
		res.redirect(found[0].Path)
	});

})
router.get('/download_mac/:id', (req, res) => {
	
	con.query("SELECT * FROM mac WHERE uid=? LIMIT 1",[
		req.params.id
	 ], function (err, found) {
		//console.log(windows[0].Path);
		res.redirect(found[0].Path)
	});

})
router.get('/download_linux/:id', (req, res) => {
	
	con.query("SELECT * FROM linux WHERE uid=? LIMIT 1",[
		req.params.id
	 ], function (err, found) {
		//console.log(windows[0].Path);
		res.redirect(found[0].Path)
	});	

})
router.get('/download_android/:id', (req, res) => {
	
	con.query("SELECT * FROM android WHERE uid=? LIMIT 1",[
		req.params.id
	 ], function (err, found) {
		//console.log(windows[0].Path);
		res.redirect(found[0].Path)
	});	

})

router.post('/search', (req, res) => {
	var query=req.body.title.split('');
	
	var check=0;
		for (var i=0;i<query.length;i++)
		{
			if(!((query[i]>='a' && query[i]<='z') || (query[i]>='A' && query[i]<='Z') || (query[i]>='0' && query[i]<='9') || (query[i]==' ')) )
			{
           check=1;
			}
		}
		if(check==1)
		{
			//console.log("ahhahaaaaaaaaaaaaaaa")
			res.render('search',{
				Found:'',
				Type:req.body.type,
				Key:req.body.title
					});
		}

	if(req.body.type=="Windows")
	{			
		
				con.query("SELECT * FROM windows where Title LIKE ?",[
					'%'+req.body.title+'%'
					
				],function (err, found) {
					 console.log(found);
					res.render('search',{
						Found:found,
						Type:req.body.type,
						Key:req.body.title
							});
						});
        

	}
	else if(req.body.type=="Linux")
	{
		con.query("SELECT * FROM linux where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});

	}
	else if(req.body.type=="Mac")
	{
		con.query("SELECT * FROM mac where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});
	}
	else if(req.body.type=="APK")
	{
		con.query("SELECT * FROM android where Title LIKE ?",[
			'%'+req.body.title+'%'
			
		],function (err, found) {
			 console.log(found);
			res.render('search',{
				Found:found,
				Type:req.body.type,
				Key:req.body.title
					});
				});

	}
});
router.get('/mac', (req, res) => {
	
	con.query("SELECT * FROM mac ORDER BY Date DESC", function (err, result) {
		if (err) throw err;
		res.render('mac',{
			Mac: result
			});
	});
});
router.get('/linux', (req, res) => {
	
	con.query("SELECT * FROM linux ORDER BY Date DESC", function (err, result) {
		if (err) throw err;
		res.render('linux',{
			Linux: result
			});
	});
});
router.get('/autocomplete/', (req, res) => {
	var regex= new RegExp(req.query["term"],'i');

	var filter=Windows.find({Title:regex},{'Title':1}).sort({"updated_at":-1}).sort({"created_at":-1}).limit(10);
 filter.exec(function(err,data){
 
	var result=[];
	if(!err){
		if(data && data.length && data.length>0){
			data.forEach(user=>{
				let obj={
					id:user._id,
					label: user.Title
				};
				result.push(obj);
			});
		}
		console.log(result);
		res.jsonp(result);
	}

 });

});
router.get('/android', (req, res) => {
	
		
			con.query("SELECT * FROM android ORDER BY Date DESC", function (err, result) {
				if (err) throw err;
				res.render('android',{
					Apk: result
					});
			});
});


router.post('/upload_papular', (req, res) => {

	if(req.session.name)
	{

	new formidable.IncomingForm().parse(req, (err, fields, files) => {
		 
		let errors=[];
		if (err) {
      console.error('Error', err)
      throw err
		}
			console.log(files);
		if(!fields.title){
			errors.push("Please Enter title");
		}
		if(!fields.version){
			errors.push("Please Enter version");
		}
		if(!fields.size){
			errors.push("Please Enter size");
		}
		if(!fields.type){
			errors.push("Please select type");
		}
		
		if(errors.length>0)
		{
			console.log(errors);
			
			return res.end("Plz Fill All Fields")
		}
		
	});
 
	uploadpic(req,res,function(err) {
		let errors=[];
		if(err) {
			console.log("error");
					return res.end("first error Error uploading file.");
			}
		
		//console.log('The filename is ' + res.req.file.filename);
		
		console.log(filename);
		console.log(picname);
		var today = new Date();
	var date = (today.getMonth()+1)+'-'+today.getDate()+'-'+today.getFullYear();
	var title=req.body.title;
	var version=req.body.version;
	var size=req.body.size;
	var icon = 'Files/' + picname;
	var d= date;
	var path = req.body.link;
			if(req.body.type=="Windows")
			{
				con.query("SELECT * FROM papular ORDER BY Date DESC", function (err, result) {
					if (err) throw err;
					//console.log(result[1].id);
						if(result.length==10)
						{
							var sql = "DELETE FROM papular WHERE Title = '"+result[result.length-1].Title+"'";
              con.query(sql, function (err, result) {
							if (err) throw err;
							console.log("10 record deleted");
							});
							
							var sql = "INSERT INTO papular (uid, Title,Icon,Size,Version,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+d+"')";
							con.query(sql, function (err, result) {
								if (err) throw err;
								console.log("1 record inserted");
						});
							
						}
						else
						{
							var sql = "INSERT INTO papular (uid, Title,Icon,Size,Version,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+d+"')";
							con.query(sql, function (err, result) {
								if (err) throw err;
								console.log("1 record inserted");
						});

						}
				});
				
				
				var sql = "INSERT INTO windows (uid, Title,Icon,Size,Version,Path,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+path+"','"+d+"')";
				con.query(sql, function (err, result) {
					if (err) throw err;
					console.log("1 record inserted");
					return res.end("Record Succesfully Saved in Database Please refresh the page");
			
			});
			
	
			}
			else if(req.body.type=="Linux")
			{
				
					var sql = "INSERT INTO linux (uid, Title,Icon,Size,Version,Path,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+path+"','"+d+"')";
					con.query(sql, function (err, result) {
						if (err) throw err;
						console.log("1 record inserted");
						return res.end("Record Succesfully Saved in Database Please refresh the page");
					});
				
			}
			else if(req.body.type=="Mac")
			{
				
					
					var sql = "INSERT INTO mac (uid, Title,Icon,Size,Version,Path,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+path+"','"+d+"')";
					con.query(sql, function (err, result) {
						if (err) throw err;
						console.log("1 record inserted");
						return res.end("Record Succesfully Saved in Database Please refresh the page");
					});
			
			}
			else if(req.body.type=="APK")
			{
				
					var sql = "INSERT INTO android (uid, Title,Icon,Size,Version,Path,Date) VALUES ('"+uniqueString()+"','"+title+"','"+icon+"','"+size+"','"+version+"','"+path+"','"+d+"')";
					con.query(sql, function (err, result) {
						if (err) throw err;
						console.log("1 record inserted");
						return res.end("Record Succesfully Saved in Database Please refresh the page");
				
				});
			}
			

	});
	}
	else
	{
		res.end("You have not permission to Access this page!");
	}
	
});




	



   
module.exports = router